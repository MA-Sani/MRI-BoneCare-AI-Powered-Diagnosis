import os
import torch
import pandas as pd
from tqdm import tqdm
from PIL import Image
import configparser
import logging
import matplotlib
matplotlib.use('Agg')
import sys
from torchvision.models.detection import fasterrcnn_resnet50_fpn, FasterRCNN_ResNet50_FPN_Weights
from torchvision.ops import nms, box_iou
import numpy as np
from typing import List, Dict, Any, Tuple
from sklearn.metrics import confusion_matrix

try:
    import matplotlib.pyplot as plt
    import seaborn as sns
    import matplotlib.patches as patches  # <-- Added here
    PLOT_AVAILABLE = True
except ImportError:
    PLOT_AVAILABLE = False


class BoneTumorDetector:

    def __init__(self, threshold: float = 0.7, iou_threshold: float = 0.4):  # Adjusted defaults
        self._init_logger()
        self.logger.info("Initializing BoneTumorDetector")
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.threshold = threshold
        self.iou_threshold = iou_threshold  # Added IoU threshold attribute

        self.config = self._load_config()

        # Setup directory for saving plots
        self.plot_dir = os.path.abspath(self.config.get('PATHS', 'PlotDirectory', fallback='plots'))
        os.makedirs(self.plot_dir, exist_ok=True)

        try:
            self.logger.info("Loading detection model with weights...")
            weights = FasterRCNN_ResNet50_FPN_Weights.DEFAULT
            self.model = fasterrcnn_resnet50_fpn(weights=weights).to(self.device).eval()
            self.transform = weights.transforms()
            self.logger.info("Model loaded successfully.")
        except Exception as e:
            self.logger.critical(f"Model loading failed: {str(e)}")
            raise

    def _init_logger(self) -> None:
        self.logger = logging.getLogger('BoneTumorDetector')
        self.logger.setLevel(logging.DEBUG)
        if not self.logger.handlers:
            file_handler = logging.FileHandler('bonecare.log')
            console_handler = logging.StreamHandler()
            formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
            self.logger.addHandler(file_handler)
            self.logger.addHandler(console_handler)

    def _load_config(self) -> configparser.ConfigParser:
        config = configparser.ConfigParser()
        try:
            if not os.path.exists('systemfile.ini'):
                raise FileNotFoundError("Config file not found: systemfile.ini")
            config.read('systemfile.ini')
        except Exception as e:
            self.logger.error(f"Failed to load config: {str(e)}")
            raise
        return config

    def match_predictions_to_ground_truth(
        self,
        pred_boxes: np.ndarray,
        gt_boxes: np.ndarray,
    ) -> Tuple[List[bool], int]:
        """Enhanced matching with debug logging"""
        if len(gt_boxes) == 0:
            return [False] * len(pred_boxes), 0

        self.logger.debug(f"Matching {len(pred_boxes)} predictions to {len(gt_boxes)} GT boxes")

        pred_boxes_tensor = torch.tensor(pred_boxes)
        gt_boxes_tensor = torch.tensor(gt_boxes)

        # Matrix of IoU between all predictions and GT
        iou_matrix = box_iou(pred_boxes_tensor, gt_boxes_tensor)

        matched_gt = set()
        tp_flags = [False] * len(pred_boxes)

        # For each prediction, find the GT with highest IoU
        for pred_idx in range(len(pred_boxes)):
            best_gt = torch.argmax(iou_matrix[pred_idx]).item()
            best_iou = iou_matrix[pred_idx, best_gt].item()

            if best_iou >= self.iou_threshold and best_gt not in matched_gt:
                tp_flags[pred_idx] = True
                matched_gt.add(best_gt)
                self.logger.debug(f"Match: pred {pred_idx} <-> GT {best_gt} (IoU: {best_iou:.2f})")
            else:
                self.logger.debug(f"No match: pred {pred_idx} (best IoU: {best_iou:.2f})")

        num_fn = len(gt_boxes) - len(matched_gt)
        return tp_flags, num_fn

    def predict(
        self,
        image_paths: List[str],
        ground_truth: Dict[str, List[List[int]]] = None,
        evaluate: bool = False
    ) -> List[Dict[str, Any]]:
        try:
            output_csv = os.path.abspath(self.config.get('PATHS', 'DetectionResults', fallback='detection_results.csv'))
            limit = self.config.getint('SYSTEM', 'Limit', fallback=20)
        except configparser.NoSectionError:
            output_csv = os.path.abspath('detection_results.csv')
            limit = 20

        results = []
        all_scores, all_tp_flags = [], []
        total_fn = total_gt = 0

        # Single progress bar for all images
        with tqdm(total=min(len(image_paths), limit), desc="Detecting Tumor") as pbar:
            for img_path in image_paths[:limit]:
                try:
                    img = Image.open(img_path).convert('RGB')
                    tensor = self.transform(img).unsqueeze(0).to(self.device)

                    with torch.inference_mode():
                        outputs = self.model(tensor)[0]

                    boxes, scores = outputs["boxes"], outputs["scores"]
                    keep = nms(boxes, scores, iou_threshold=0.5)
                    boxes = boxes[keep].cpu().numpy()
                    scores = scores[keep].cpu().numpy()

                    filtered_indices = scores >= self.threshold
                    boxes, scores = boxes[filtered_indices], scores[filtered_indices]

                    for box, score in zip(boxes, scores):
                        results.append({
                            'Image': os.path.basename(img_path),
                            'Detection': 'Tumor Detected',
                            'Coordinates': f"{int(box[0])},{int(box[1])},{int(box[2])},{int(box[3])}",
                            'Confidence': f"{score:.4f}",
                            'Label': 'Tumor'
                        })

                    if evaluate and ground_truth is not None:
                        img_name = os.path.basename(img_path)
                        gt_boxes = np.array(ground_truth.get(img_name, []))
                        tp_flags, num_fn_img = self.match_predictions_to_ground_truth(boxes, gt_boxes)
                        all_scores.extend(scores.tolist())
                        all_tp_flags.extend(tp_flags)
                        total_fn += num_fn_img
                        total_gt += len(gt_boxes)

                        # Visual debug after prediction
                        self.visualize_detections(img_path, boxes.tolist(), gt_boxes.tolist())

                except Exception as e:
                    self.logger.error(f"Error processing {img_path}: {str(e)}")
                finally:
                    if 'tensor' in locals():
                        del tensor
                        torch.cuda.empty_cache()
                    pbar.update(1)

        df = pd.DataFrame(results)
        df.to_csv(output_csv, index=False)
        self.logger.info(f"Results saved to {output_csv}")

        if evaluate and ground_truth is not None and (all_scores or total_gt):
            self._compute_and_log_metrics(all_scores, all_tp_flags, total_fn, total_gt)

        return results

    def _compute_and_log_metrics(
            self,
            all_scores: List[float],
            all_tp_flags: List[bool],
            total_fn: int,
            total_gt: int
    ) -> None:
        total_tp = sum(all_tp_flags)
        total_fp = len(all_tp_flags) - total_tp
        precision = total_tp / (total_tp + total_fp + 1e-10)
        recall = total_tp / (total_tp + total_fn + 1e-10)
        f1 = 2 * (precision * recall) / (precision + recall + 1e-10)

        cm = np.array([[total_tp, total_fp],
                       [total_fn, 0]])

        self.logger.info(f"Metrics:\nPrecision: {precision:.4f}\nRecall: {recall:.4f}\nF1-score: {f1:.4f}")
        self.logger.info(f"Confusion Matrix:\n{cm}")

        if PLOT_AVAILABLE:
            plt.figure(figsize=(6, 5))
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
            plt.title('Confusion Matrix')
            plt.xlabel('Predicted')
            plt.ylabel('Actual')

            # Save normally to file
            file_path = os.path.join(self.plot_dir, 'confusion_matrix.png')
            plt.savefig(file_path)
            self.logger.info(f"Confusion matrix saved to {file_path}")

            # Optional: Save to sys.stdout.buffer (for compiler compatibility or direct output)
            try:
                plt.savefig(sys.stdout.buffer)
                sys.stdout.flush()
                self.logger.info("Confusion matrix also written to sys.stdout.buffer")
            except Exception as e:
                self.logger.warning(f"Could not write confusion matrix to sys.stdout.buffer: {e}")

            plt.close()

    def visualize_detections(self, image_path: str, pred_boxes: list, gt_boxes: list = None):
        """Visualize predictions and ground truth boxes"""
        if not PLOT_AVAILABLE:
            self.logger.warning("Visualization requires matplotlib")
            return

        fig, ax = plt.subplots(1, figsize=(12, 8))
        img = Image.open(image_path)
        ax.imshow(img)

        # Draw prediction boxes in red
        for box in pred_boxes:
            rect = patches.Rectangle(
                (box[0], box[1]), box[2] - box[0], box[3] - box[1],
                linewidth=2, edgecolor='r', facecolor='none', label='Prediction'
            )
            ax.add_patch(rect)

        # Draw ground truth boxes in green
        if gt_boxes:
            for box in gt_boxes:
                rect = patches.Rectangle(
                    (box[0], box[1]), box[2] - box[0], box[3] - box[1],
                    linewidth=2, edgecolor='g', facecolor='none', label='Ground Truth'
                )
                ax.add_patch(rect)

        plt.title(f"Detections and Ground Truth for {os.path.basename(image_path)}")
        plt.axis('off')
        save_path = os.path.join(self.plot_dir, os.path.basename(image_path).replace('.jpg', '_det.png'))
        plt.savefig(save_path)
        plt.close()
        self.logger.info(f"Saved detection visualization to {save_path}")
