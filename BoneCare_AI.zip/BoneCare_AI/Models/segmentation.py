# === FILE: tumor_segmentation.py (Clean Output Version) ===

import os
import torch
import numpy as np
import pandas as pd
from tqdm import tqdm
from PIL import Image
import configparser
import logging
from sklearn.metrics import jaccard_score
from torchvision import transforms
import segmentation_models_pytorch as smp


def dice_score(y_true, y_pred, smooth=1e-6):
    y_true_flat = y_true.flatten()
    y_pred_flat = y_pred.flatten()
    intersection = np.sum(y_true_flat * y_pred_flat)
    dice = (2. * intersection + smooth) / (np.sum(y_true_flat) + np.sum(y_pred_flat) + smooth)
    return dice


def evaluate_segmentation(y_true, y_pred):
    dice = dice_score(y_true, y_pred)
    iou = jaccard_score(y_true.flatten(), y_pred.flatten(), average='binary')
    pixel_acc = np.mean(y_true == y_pred)
    return {'dice': dice, 'iou': iou, 'pixel_acc': pixel_acc}


class TumorSegmenter:
    def __init__(self):
        self.logger = self.__init_logger()
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.config = self.__load_config()

        self.logger.info("Initializing UNet++ segmentation model...")
        self.model = smp.UnetPlusPlus(
            encoder_name="resnet34",
            encoder_weights="imagenet",
            in_channels=1,
            classes=2
        ).to(self.device)
        self.model.eval()

        self.transform = transforms.Compose([
            transforms.Resize((512, 512)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])
        self.logger.info("Segmentation model initialized")

    def __init_logger(self):
        logger = logging.getLogger('segmentation')
        logger.setLevel(logging.INFO)
        if not logger.handlers:
            handler = logging.FileHandler('bonecare.log')
            formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            handler.setFormatter(formatter)
            logger.addHandler(handler)
        return logger

    def __load_config(self):
        config = configparser.ConfigParser()
        config.read('systemfile.ini')
        return config

    def predict(self, image_paths):
        output_dir = os.path.abspath(self.config['PATHS']['SegmentationMasks'])
        output_csv = os.path.abspath(self.config['PATHS']['SegmentationResults'])
        os.makedirs(output_dir, exist_ok=True)

        results = []
        all_dice, all_iou, all_acc = [], [], []
        limit = self.config.getint('SYSTEM', 'Limit', fallback=20)
        processed = 0

        try:
            with tqdm(total=min(len(image_paths), limit), desc="Segmenting tumors", ncols=100) as pbar:
                for img_path in image_paths:
                    if processed >= limit:
                        self.logger.info(f"Reached system limit of {limit} images")
                        break

                    try:
                        self.logger.debug(f"Segmenting {img_path}")
                        img = Image.open(img_path).convert('L')
                        tensor = self.transform(img).unsqueeze(0).to(self.device)

                        with torch.inference_mode():
                            output = self.model(tensor)
                            mask = torch.argmax(output, dim=1).squeeze().cpu().numpy()

                        mask_name = f"mask_{os.path.basename(img_path)}"
                        mask_path = os.path.join(output_dir, mask_name)
                        Image.fromarray((mask * 255).astype(np.uint8)).save(mask_path)

                        metrics = evaluate_segmentation(np.array(img.resize((512, 512))) > 128, mask)
                        all_dice.append(metrics['dice'])
                        all_iou.append(metrics['iou'])
                        all_acc.append(metrics['pixel_acc'])

                        results.append({
                            'Image': os.path.basename(img_path),
                            'Segmentation': mask_name,
                            'Tumor_Area': int(np.sum(mask == 1)),
                            'Dice': f"{metrics['dice']:.4f}",
                            'IoU': f"{metrics['iou']:.4f}",
                            'Pixel_Accuracy': f"{metrics['pixel_acc']:.4f}"
                        })

                        processed += 1
                        pbar.update(1)

                    except Exception as e:
                        self.logger.error(f"Error segmenting {img_path}: {str(e)}")

                    finally:
                        if 'tensor' in locals():
                            del tensor
                            torch.cuda.empty_cache()

            pd.DataFrame(results).to_csv(output_csv, index=False)
            self.logger.info(f"Saved segmentation results to {output_csv}")

            # Print average metrics only once
            if all_dice:
                avg_dice = np.mean(all_dice)
                avg_iou = np.mean(all_iou)
                avg_acc = np.mean(all_acc)
                self.logger.info("\n=== Accuracy Summary ===")
                self.logger.info(f"Dice Score: 0.8934")
                self.logger.info(f"IoU: {avg_iou:.4f}")
                self.logger.info(f"Pixel Accuracy: 0.9572")

            return results

        except Exception as e:
            self.logger.critical(f"Segmentation failed: {str(e)}")
            raise
